package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.projecthub.databinding.ActivityTemplateBinding;

public class Template extends DrawerBasedActivity {
    ActivityTemplateBinding activityTemplateBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityTemplateBinding = ActivityTemplateBinding.inflate(getLayoutInflater());
        setContentView(activityTemplateBinding.getRoot());
        allocateActivityTitle("Template");
    }
    int requestcode = 1;

    public void onActivityResult(int requestcode, int resultCode, Intent data)
    {
        super.onActivityResult(requestcode,resultCode, data);
        Context context = getApplicationContext();
        if(requestcode == requestcode && resultCode == Activity_Log.RESULT_OK)
        {
            if(data == null)
            {
                return;
            }
            Uri uri =data.getData();

            Toast.makeText(context,uri.getPath(),Toast.LENGTH_SHORT).show();
        }
}
public  void openfilechooser(View view){
    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
    intent.setType("*/*");
    startActivityForResult(intent, requestcode);
    }
}