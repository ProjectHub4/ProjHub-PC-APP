package com.example.projecthub;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterM extends RecyclerView.Adapter<MyAdapterM.MyViewHolder> {

    private Context context;
    private ArrayList title_id;
    private ArrayList date_id;
    private ArrayList time_id;

    public MyAdapterM(Context context, ArrayList title_id, ArrayList date_id, ArrayList time_id, ArrayList discussion_id, ArrayList task_to_do_id, ArrayList status_id, ArrayList action_id) {
        this.context = context;
        this.title_id = title_id;
        this.date_id = date_id;
        this.time_id = time_id;
        this.discussion_id = discussion_id;
        this.task_to_do_id = task_to_do_id;
        this.status_id = status_id;
        this.action_id = action_id;
    }

    private ArrayList discussion_id;
    private ArrayList task_to_do_id;
    private ArrayList status_id;
    private ArrayList action_id;

    @NonNull
    @Override
    public MyAdapterM.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.meetingentry,parent,false);
        return new MyAdapterM.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapterM.MyViewHolder holder, int position) {

        holder.title_id.setText(String.valueOf(title_id.get(position)));
        holder.date_id.setText(String.valueOf(date_id.get(position)));
        holder.time_id.setText(String.valueOf(time_id.get(position)));
        holder.discussion_id.setText(String.valueOf(discussion_id.get(position)));
        holder.task_to_do_id.setText(String.valueOf(task_to_do_id.get(position)));
        holder.status_id.setText(String.valueOf(status_id.get(position)));
        holder.action_id.setText(String.valueOf(action_id.get(position)));

    }

    @Override
    public int getItemCount() {
        return title_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView title_id,date_id,time_id,discussion_id,task_to_do_id,status_id,action_id;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            title_id = itemView.findViewById(R.id.textmtitle);
            date_id = itemView.findViewById(R.id.textdate);
            time_id = itemView.findViewById(R.id.texttime);
            discussion_id = itemView.findViewById(R.id.textdis);
            task_to_do_id = itemView.findViewById(R.id.textttd);
            status_id = itemView.findViewById(R.id.textstatus);
            action_id = itemView.findViewById(R.id.textaction);
        }
    }
}
