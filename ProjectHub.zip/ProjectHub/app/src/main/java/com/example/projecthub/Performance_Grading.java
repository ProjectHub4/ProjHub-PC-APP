package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Performance_Grading extends AppCompatActivity {
    Button showpr,insertpr;
    EditText projecttitlepr,student1pr,student2pr,student3pr,student4pr,remarkpr,codeevaluationpr,projectevaluationpr,performancepr,participationpr,midevaluationpr,finalevaluationpr,projectstatuspr;
    DBHelper MyDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_performance_grading);
        showpr = (Button) findViewById(R.id.showpr);
        projecttitlepr = (EditText) findViewById(R.id.projecttitlepr);
        student1pr = (EditText) findViewById(R.id.student1pr);
        student2pr = (EditText) findViewById(R.id.student2pr);
        student3pr = (EditText) findViewById(R.id.student3pr);
        student4pr = (EditText) findViewById(R.id.student4pr);
        remarkpr = (EditText) findViewById(R.id.remarkpr);
        codeevaluationpr = (EditText) findViewById(R.id.codeevaluationpr);
        projectevaluationpr = (EditText) findViewById(R.id.projectevaluationpr);
        performancepr = (EditText) findViewById(R.id.performancepr);
        participationpr = (EditText) findViewById(R.id.participationpr);
        midevaluationpr = (EditText) findViewById(R.id.midevaluationpr);
        finalevaluationpr = (EditText) findViewById(R.id.finalevaluationpr);
        projectstatuspr = (EditText) findViewById(R.id.projectstatuspr);
        showpr = findViewById(R.id.showpr);
        insertpr = findViewById(R.id.insertpr);
        MyDB = new DBHelper(this);

        showpr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNewActivity();
            }

        });
        insertreport();
    }
    private void openNewActivity() {
        Intent intent = new Intent(this, Progress_Report.class);
        startActivity(intent);
    }

    public void insertreport(){
        insertpr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean Inserted = MyDB.insertData5(projecttitlepr.getText().toString(),student1pr.getText().toString(),student2pr.getText().toString(),
                        student3pr.getText().toString(),student4pr.getText().toString(),remarkpr.getText().toString(),codeevaluationpr.getText().toString(),
                        projectevaluationpr.getText().toString(),performancepr.getText().toString(),participationpr.getText().toString(),midevaluationpr.getText().toString(),finalevaluationpr.getText().toString(),projectstatuspr.getText().toString());
                if(Inserted){
                    Toast.makeText(Performance_Grading.this, "Progress inserted", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Performance_Grading.this, "Not inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}


