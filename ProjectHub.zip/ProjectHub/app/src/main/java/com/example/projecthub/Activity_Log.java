package com.example.projecthub;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.projecthub.databinding.Activity1Binding;

import java.util.ArrayList;

public class Activity_Log extends DrawerBasedActivity {
    Activity1Binding activity1Binding;
    Button addactivity;
    RecyclerView recycler_activity;
    ArrayList<String> title,grade,adate,acdy,atime,adp;
    DBHelper DB;
    MyAdapterAc adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity1Binding = Activity1Binding.inflate(getLayoutInflater());
        setContentView(activity1Binding.getRoot());
        allocateActivityTitle("Activity Log");
        addactivity = (Button) findViewById(R.id.addactivity);
        addactivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNewActivity();
            }
        });


        DB = new DBHelper(this);
        title = new ArrayList<>();
        grade = new ArrayList<>();
        adate = new ArrayList<>();
        acdy = new ArrayList<>();
        atime = new ArrayList<>();
        adp = new ArrayList<>();
        recycler_activity = findViewById(R.id.recycler_activity);
        adapter =  new MyAdapterAc(this,title,grade,adate,acdy,atime,adp);
        recycler_activity.setAdapter(adapter);
        recycler_activity.setLayoutManager(new LinearLayoutManager(this));
        displayactivitydata();

    }
    private void displayactivitydata() {

        Cursor cursor = DB.getactivitydata();
        if(cursor.getCount()==0){
            Toast.makeText(this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            while(cursor.moveToNext()){
                title.add(cursor.getString(0));
                grade.add(cursor.getString(1));
                adate.add(cursor.getString(2));
                acdy.add(cursor.getString(3));
                atime.add(cursor.getString(4));
                adp.add(cursor.getString(5));
            }
        }

    }
    private void openNewActivity() {
        Intent intent = new Intent(this, Create_Activity.class);
        startActivity(intent);
    }

}

