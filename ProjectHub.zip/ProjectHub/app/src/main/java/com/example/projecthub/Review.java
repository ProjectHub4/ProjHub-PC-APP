package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projecthub.databinding.ActivityReviewBinding;

import java.util.ArrayList;

public class Review extends DrawerBasedActivity {
    ActivityReviewBinding activityReviewBinding;
    Button addreview;
    RecyclerView recycler_menu;
    ArrayList<String> projtitle,comment;
    DBHelper DB;
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityReviewBinding = ActivityReviewBinding.inflate(getLayoutInflater());
        setContentView(activityReviewBinding.getRoot());
        allocateActivityTitle("Review");
        addreview=findViewById(R.id.addreview);
        addreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNewActivity();
            }
        });

        DB = new DBHelper(this);
        projtitle = new ArrayList<>();
        comment = new ArrayList<>();
        recycler_menu = findViewById(R.id.recycler_menu);
        adapter =  new MyAdapter(this,projtitle,comment);
        recycler_menu.setAdapter(adapter);
        recycler_menu.setLayoutManager(new LinearLayoutManager(this));
        displayreviewdata();
    }

    private void displayreviewdata() {

        Cursor cursor = DB.getreviewdata();
        if(cursor.getCount()==0){
            Toast.makeText(this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            while(cursor.moveToNext()){
                projtitle.add(cursor.getString(0));
                comment.add(cursor.getString(1));
            }
        }

    }

    private void openNewActivity() {
        Intent intent = new Intent(this, Add_Review.class);
        startActivity(intent);
    }


}