package com.example.projecthub;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterEP extends RecyclerView.Adapter<MyAdapterEP.MyViewHolder> {

    Context context;
    private ArrayList eid_id,ept_id,s1_id,s2_id,s3_id,s4_id,eacdy_id,ebatch_id,esup_id;

    public MyAdapterEP(Context context, ArrayList eid_id, ArrayList ept_id, ArrayList s1_id, ArrayList s2_id, ArrayList s3_id, ArrayList s4_id, ArrayList eacdy_id, ArrayList ebatch_id, ArrayList esup_id) {
        this.context = context;
        this.eid_id = eid_id;
        this.ept_id = ept_id;
        this.s1_id = s1_id;
        this.s2_id = s2_id;
        this.s3_id = s3_id;
        this.s4_id = s4_id;
        this.eacdy_id = eacdy_id;
        this.ebatch_id = ebatch_id;
        this.esup_id = esup_id;
    }

    @NonNull
    @Override
    public MyAdapterEP.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.enrollprojectentry,parent,false);
        return new MyAdapterEP.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapterEP.MyViewHolder holder, int position) {

        holder.eid_id.setText(String.valueOf(eid_id.get(position)));
        holder.ept_id.setText(String.valueOf(ept_id.get(position)));
        holder.s1_id.setText(String.valueOf(s1_id.get(position)));
        holder.s2_id.setText(String.valueOf(s2_id.get(position)));
        holder.s3_id.setText(String.valueOf(s3_id.get(position)));
        holder.s4_id.setText(String.valueOf(s4_id.get(position)));
        holder.eacdy_id.setText(String.valueOf(eacdy_id.get(position)));
        holder.ebatch_id.setText(String.valueOf(ebatch_id.get(position)));
        holder.esup_id.setText(String.valueOf(esup_id.get(position)));

    }

    @Override
    public int getItemCount() {
        return eid_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView eid_id,ept_id,s1_id,s2_id,s3_id,s4_id,eacdy_id,ebatch_id,esup_id;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            eid_id = itemView.findViewById(R.id.texteid);
            ept_id = itemView.findViewById(R.id.textept);
            s1_id = itemView.findViewById(R.id.texts1);
            s2_id = itemView.findViewById(R.id.texts2);
            s3_id = itemView.findViewById(R.id.texts3);
            s4_id = itemView.findViewById(R.id.texts4);
            eacdy_id = itemView.findViewById(R.id.texteacdy);
            ebatch_id = itemView.findViewById(R.id.textebatch);
            esup_id = itemView.findViewById(R.id.textesup);

        }
    }
}
