package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Schedule_Meeting extends AppCompatActivity {

    EditText title,date,time,dis,status,ttd,action;
    Button meetinginsert,showmeeting;
    DBHelper MyDB;
    int year,month,day,currenthour,currentminute;
    TimePickerDialog timePickerDialog;
    String amPm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_schedule_meeting);
        title = findViewById(R.id.title);
        date = findViewById(R.id.date);
        Calendar calendar = Calendar.getInstance();
        time = findViewById(R.id.time);
        dis = findViewById(R.id.dis);
        ttd = findViewById(R.id.ttd);
        action = findViewById(R.id.action);
        status = findViewById(R.id.status);
        meetinginsert = findViewById(R.id.meetinginsert);
        showmeeting = findViewById(R.id.showmeeting);
        MyDB = new DBHelper(this);

        insertMeeting();

        showmeeting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Schedule_Meeting.this, Meeting.class));
            }
        });

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(Schedule_Meeting.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        date.setText(SimpleDateFormat.getDateInstance().format(calendar.getTime()));
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currenthour = calendar.get(Calendar.HOUR_OF_DAY);
                currentminute = calendar.get(Calendar.MINUTE);

                timePickerDialog = new TimePickerDialog(Schedule_Meeting.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        if (hourOfDay >= 12){
                            amPm = "PM";
                        }else{
                            amPm = "AM";
                        }
                        time.setText(String.format("%02d:%02d",hourOfDay,minutes) + amPm);
                    }
                },currenthour,currentminute,false);
                timePickerDialog.show();
            }
        });
    }
    public void insertMeeting() {
        meetinginsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean Inserted = MyDB.insertData3(title.getText().toString(),date.getText().toString(),time.getText().toString()
                ,dis.getText().toString(),ttd.getText().toString(),status.getText().toString(),action.getText().toString());
                if (Inserted) {
                    Toast.makeText(Schedule_Meeting.this, "Meeting Inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Schedule_Meeting.this, "Not Inserted", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}