package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Create_Activity extends AppCompatActivity {

    EditText adate,atime,atitle,agrade,acdy,adp;
    Button activityinsert,activityshow;
    DBHelper MyDB;
    int year,month,day,currenthour,currentminute;
    TimePickerDialog timePickerDialog;
    String amPm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        adate = (EditText) findViewById(R.id.adate);
        atime = (EditText) findViewById(R.id.atime);
        Calendar calendar = Calendar.getInstance();
        atitle = findViewById(R.id.atitle);
        agrade = findViewById(R.id.agrade);
        acdy = findViewById(R.id.acdy);
        adp = findViewById(R.id.adp);
        activityinsert = findViewById(R.id.activtyinsert);
        activityshow = findViewById(R.id.activityshow);
        MyDB = new DBHelper(this);

        activityshow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Create_Activity.this, Activity_Log.class));
            }
        });


        adate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(Create_Activity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        adate.setText(SimpleDateFormat.getDateInstance().format(calendar.getTime()));
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });
        atime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currenthour = calendar.get(Calendar.HOUR_OF_DAY);
                currentminute = calendar.get(Calendar.MINUTE);

                timePickerDialog = new TimePickerDialog(Create_Activity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        if (hourOfDay >= 12){
                            amPm = "PM";
                        }else{
                            amPm = "AM";
                        }
                        atime.setText(String.format("%02d:%02d",hourOfDay,minutes) + amPm);
                    }
                },currenthour,currentminute,false);
                timePickerDialog.show();
            }
        });
        insertActivity();
    }

    public void insertActivity(){
        activityinsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean Inserted = MyDB.insertData2(atitle.getText().toString(),agrade.getText().toString(),adate.getText().toString(),acdy.getText().toString(),atime.getText().toString(),adp.getText().toString());
                if(Inserted){
                    Toast.makeText(Create_Activity.this, "Activity inserted", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Create_Activity.this, "Not inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
