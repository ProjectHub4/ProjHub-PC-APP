package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.projecthub.databinding.ActivityDashboardBinding;
import com.example.projecthub.databinding.ActivityProjectBinding;

public class Project extends DrawerBasedActivity {
    ActivityProjectBinding activityProjectBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityProjectBinding = ActivityProjectBinding.inflate(getLayoutInflater());
        setContentView(activityProjectBinding.getRoot());
        allocateActivityTitle("Project");

    }
}