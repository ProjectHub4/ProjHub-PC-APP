package com.example.projecthub;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private Context context;
    private ArrayList projtitle_id, comment_id;

    public MyAdapter(Context context, ArrayList projtitle_id, ArrayList comment_id) {
        this.context = context;
        this.projtitle_id = projtitle_id;
        this.comment_id = comment_id;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.reviewentry,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.projtitle_id.setText(String.valueOf(projtitle_id.get(position)));
        holder.comment_id.setText(String.valueOf(comment_id.get(position)));

    }

    @Override
    public int getItemCount() {
        return projtitle_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView projtitle_id, comment_id;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            projtitle_id = itemView.findViewById(R.id.textpt);
            comment_id = itemView.findViewById(R.id.textct);
        }
    }
}
