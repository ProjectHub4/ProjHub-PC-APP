package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.projecthub.databinding.ActivityDashboardBinding;
import com.example.projecthub.databinding.ActivityMeetingBinding;

import java.util.ArrayList;
import java.util.List;

public class Meeting extends DrawerBasedActivity {
    ActivityMeetingBinding activityMeetingBinding;
    Button addmeeting;
    RecyclerView recycler_meeting;
    ArrayList<String> title,date,time,dis,ttd,status,action;
    DBHelper DB;
    MyAdapterM adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMeetingBinding = ActivityMeetingBinding.inflate(getLayoutInflater());
        setContentView(activityMeetingBinding.getRoot());
        allocateActivityTitle("Meeting");
        addmeeting =(Button) findViewById(R.id.addmeeting);
        addmeeting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNewActivity();
            }
        });

        DB = new DBHelper(this);
        title = new ArrayList<>();
        date = new ArrayList<>();
        time = new ArrayList<>();
        dis = new ArrayList<>();
        ttd = new ArrayList<>();
        status = new ArrayList<>();
        action = new ArrayList<>();
        recycler_meeting = findViewById(R.id.recycler_meeting);
        adapter =  new MyAdapterM(this,title,date,time,dis,ttd,status,action);
        recycler_meeting.setAdapter(adapter);
        recycler_meeting.setLayoutManager(new LinearLayoutManager(this));
        displaymeetingdata();
    }

    private void displaymeetingdata() {

        Cursor cursor = DB.getmeetingdata();
        if(cursor.getCount()==0){
            Toast.makeText(this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            while(cursor.moveToNext()){
                title.add(cursor.getString(0));
                date.add(cursor.getString(1));
                time.add(cursor.getString(2));
                dis.add(cursor.getString(3));
                ttd.add(cursor.getString(4));
                status.add(cursor.getString(5));
                action.add(cursor.getString(6));
            }
        }

    }

    private void openNewActivity() {
        Intent intent = new Intent(this, Schedule_Meeting.class);
        startActivity(intent);
    }


    }
