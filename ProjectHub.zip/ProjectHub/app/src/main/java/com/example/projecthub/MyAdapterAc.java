package com.example.projecthub;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterAc extends RecyclerView.Adapter<MyAdapterAc.MyViewHolder> {

    private Context context;
    private ArrayList title_id, grade_id, adate_id, acdy_id, atime_id, adp_id;

    public MyAdapterAc(Context context, ArrayList title_id, ArrayList grade_id, ArrayList adate_id, ArrayList acdy_id, ArrayList atime_id, ArrayList adp_id) {
        this.context = context;
        this.title_id = title_id;
        this.grade_id = grade_id;
        this.adate_id = adate_id;
        this.acdy_id = acdy_id;
        this.atime_id = atime_id;
        this.adp_id = adp_id;
    }

    @NonNull
    @Override
    public MyAdapterAc.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activityentry,parent,false);
        return new MyAdapterAc.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapterAc.MyViewHolder holder, int position) {

        holder.title_id.setText(String.valueOf(title_id.get(position)));
        holder.grade_id.setText(String.valueOf(grade_id.get(position)));
        holder.adate_id.setText(String.valueOf(adate_id.get(position)));
        holder.acdy_id.setText(String.valueOf(acdy_id.get(position)));
        holder.atime_id.setText(String.valueOf(atime_id.get(position)));
        holder.adp_id.setText(String.valueOf(adp_id.get(position)));

    }

    @Override
    public int getItemCount() {
        return title_id.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView title_id,grade_id,adate_id,acdy_id,atime_id,adp_id;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            title_id =itemView.findViewById(R.id.texttitle);
            grade_id =itemView.findViewById(R.id.textgrade);
            adate_id =itemView.findViewById(R.id.textdate);
            acdy_id =itemView.findViewById(R.id.textacdy);
            atime_id =itemView.findViewById(R.id.texttime);
            adp_id =itemView.findViewById(R.id.textadp);

        }
    }
}
