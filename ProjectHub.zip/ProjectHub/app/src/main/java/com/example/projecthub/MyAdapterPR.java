package com.example.projecthub;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterPR extends RecyclerView.Adapter<MyAdapterPR.MyViewHolder> {

    Context context;
    private ArrayList<String> projecttitlepr_id,student1pr_id,student2pr_id,student3pr_id,student4pr_id,remarkpr_id,codeevaluationpr_id,projectevaluationpr_id,performancepr_id,participationpr_id,midevaluationpr_id,finalevaluationpr_id,projectstatuspr_id;

    public MyAdapterPR(Context context, ArrayList<String> projecttitlepr_id, ArrayList<String> student1pr_id, ArrayList<String> student2pr_id, ArrayList<String> student3pr_id, ArrayList<String> student4pr_id, ArrayList<String> remarkpr_id, ArrayList<String> codeevaluationpr_id, ArrayList<String> projectevaluationpr_id, ArrayList<String> performancepr_id, ArrayList<String> participationpr_id, ArrayList<String> midevaluationpr_id, ArrayList<String> finalevaluationpr_id, ArrayList<String> projectstatuspr_id) {
        this.context = context;
        this.projecttitlepr_id = projecttitlepr_id;
        this.student1pr_id = student1pr_id;
        this.student2pr_id = student2pr_id;
        this.student3pr_id = student3pr_id;
        this.student4pr_id = student4pr_id;
        this.remarkpr_id = remarkpr_id;
        this.codeevaluationpr_id = codeevaluationpr_id;
        this.projectevaluationpr_id = projectevaluationpr_id;
        this.performancepr_id = performancepr_id;
        this.participationpr_id = participationpr_id;
        this.midevaluationpr_id = midevaluationpr_id;
        this.finalevaluationpr_id = finalevaluationpr_id;
        this.projectstatuspr_id = projectstatuspr_id;
    }

    @NonNull
    @Override
    public MyAdapterPR.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.projectreportentry,parent,false);
        return new MyAdapterPR.MyViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapterPR.MyViewHolder holder, int position) {
        holder.projecttitlepr_id.setText(String.valueOf(projecttitlepr_id.get(position)));
        holder.student1pr_id.setText(String.valueOf(student1pr_id.get(position)));
        holder.student2pr_id.setText(String.valueOf(student2pr_id.get(position)));
        holder.student3pr_id.setText(String.valueOf(student3pr_id.get(position)));
        holder.student4pr_id.setText(String.valueOf(student4pr_id.get(position)));
        holder.remarkpr_id.setText(String.valueOf(remarkpr_id.get(position)));
        holder.codeevaluationpr_id.setText(String.valueOf(codeevaluationpr_id.get(position)));
        holder.projectevaluationpr_id.setText(String.valueOf(projectevaluationpr_id.get(position)));
        holder.performancepr_id.setText(String.valueOf(performancepr_id.get(position)));
        holder.participationpr_id.setText(String.valueOf(participationpr_id.get(position)));
        holder.midevaluationpr_id.setText(String.valueOf(midevaluationpr_id.get(position)));
        holder.finalevaluationpr_id.setText(String.valueOf(finalevaluationpr_id.get(position)));
        holder.projectstatuspr_id.setText(String.valueOf(projectstatuspr_id.get(position)));

    }

    @Override
    public int getItemCount() {
        return projecttitlepr_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView projecttitlepr_id,student1pr_id,student2pr_id,student3pr_id,student4pr_id,remarkpr_id,codeevaluationpr_id,projectevaluationpr_id,performancepr_id,participationpr_id,midevaluationpr_id,finalevaluationpr_id,projectstatuspr_id;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            projecttitlepr_id = itemView.findViewById(R.id.textprojectttitle);
            student1pr_id = itemView.findViewById(R.id.textstudent1);
            student2pr_id = itemView.findViewById(R.id.textstudent2);
            student3pr_id = itemView.findViewById(R.id.textstudent3);
            student4pr_id = itemView.findViewById(R.id.textstudent4);
            remarkpr_id = itemView.findViewById(R.id.textremark);
            codeevaluationpr_id = itemView.findViewById(R.id.textcodeevaluation);
            projectevaluationpr_id = itemView.findViewById(R.id.textprojectevaluation);
            performancepr_id = itemView.findViewById(R.id.textperformance);
            participationpr_id = itemView.findViewById(R.id.textparticipation);
            midevaluationpr_id = itemView.findViewById(R.id.textmidevaluation);
            finalevaluationpr_id = itemView.findViewById(R.id.textfinalevaluationpr);
            projectstatuspr_id = itemView.findViewById(R.id.textprojectstatus);
        }
    }
}
