package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.projecthub.databinding.ActivityProgressReportBinding;

import java.util.ArrayList;

public class Progress_Report extends DrawerBasedActivity{
    ActivityProgressReportBinding activityProgressReportBinding;
    Button addreport;
    RecyclerView recycler_projectreport;
    ArrayList<String> projecttitlepr,student1pr,student2pr,student3pr,student4pr,remarkpr,codeevaluationpr,projectevaluationpr,performancepr,participationpr,midevaluationpr,finalevaluationpr,projectstatuspr;
    DBHelper DB;
    MyAdapterPR adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityProgressReportBinding = ActivityProgressReportBinding.inflate(getLayoutInflater());
        setContentView(activityProgressReportBinding.getRoot());
        allocateActivityTitle("Progress Report");
        addreport = (Button) findViewById(R.id.addreport);
        addreport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNewActivity();
            }
        });

        DB = new DBHelper(this);
        projecttitlepr = new ArrayList<>();
        student1pr = new ArrayList<>();
        student2pr = new ArrayList<>();
        student3pr = new ArrayList<>();
        student4pr = new ArrayList<>();
        remarkpr = new ArrayList<>();
        codeevaluationpr = new ArrayList<>();
        projectevaluationpr = new ArrayList<>();
        performancepr = new ArrayList<>();
        participationpr = new ArrayList<>();
        midevaluationpr = new ArrayList<>();
        finalevaluationpr = new ArrayList<>();
        projectstatuspr = new ArrayList<>();
        recycler_projectreport = findViewById(R.id.recycler_projectreport);
        adapter =  new MyAdapterPR(this,projecttitlepr,student1pr,student2pr,student3pr,student4pr,remarkpr,codeevaluationpr,projectevaluationpr,performancepr
        ,participationpr,midevaluationpr,finalevaluationpr,projectstatuspr);
        recycler_projectreport.setAdapter(adapter);
        recycler_projectreport.setLayoutManager(new LinearLayoutManager(this));
        displayreportdata();
    }

    private void displayreportdata() {

        Cursor cursor = DB.getreportdata();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        } else {
            while (cursor.moveToNext()) {
                projecttitlepr.add(cursor.getString(0));
                student1pr.add(cursor.getString(1));
                student2pr.add(cursor.getString(2));
                student3pr.add(cursor.getString(3));
                student4pr.add(cursor.getString(4));
                remarkpr.add(cursor.getString(5));
                codeevaluationpr.add(cursor.getString(6));
                projectevaluationpr.add(cursor.getString(7));
                performancepr.add(cursor.getString(8));
                participationpr.add(cursor.getString(9));
                midevaluationpr.add(cursor.getString(10));
                finalevaluationpr.add(cursor.getString(11));
                projectstatuspr.add(cursor.getString(12));

            }
        }

    }
    private void openNewActivity() {
        Intent intent = new Intent(this,Performance_Grading.class);
        startActivity(intent);
    }
}