package com.example.projecthub;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "PH.db";
    public static final String DBTABLE = "users";
    public static final String DBTABLE1 = "reviews";
    public static final String DBTABLE2 = "activities";
    public static final String DBTABLE3 = "meetings";
    public static final String DBTABLE4 = "en_projects";
    public static final String DBTABLE5 = "per_report";


    public DBHelper(@Nullable Context context) {
        super(context, "PH.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table "+DBTABLE+"(username TEXT primary key, password TEXT)");
        MyDB.execSQL("create Table "+DBTABLE1+"(projtitle TEXT primary key ,comment TEXT)");
        MyDB.execSQL("create Table "+DBTABLE2+" (title TEXT primary key ,grade TEXT, date TEXT, acdy TEXT, time TEXT, dp TEXT)");
        MyDB.execSQL("create Table "+DBTABLE3+" (title TEXT primary key ,date TEXT, time TEXT, dis TEXT, ttd TEXT, status TEXT, ac TEXT)");
        MyDB.execSQL("create Table "+DBTABLE4+" (projectid TEXT primary key ,projecttitle TEXT, student1 TEXT, student2 TEXT, student3 TEXT, student4 TEXT, enrollprojectacdy TEXT, enrollbatch TEXT,enrollsupervisor)");
        MyDB.execSQL("create Table "+DBTABLE5+" (projecttitle TEXT primary key, student1 TEXT, student2 TEXT, student3 TEXT, student4 TEXT, remark TEXT, codeevaluation TEXT,projectevaluation TEXT,performance TEXT, participation TEXT, midevaluation TEXT, finalevaluation TEXT, projectstatus TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
        MyDB.execSQL("drop Table if exists reviews");
        MyDB.execSQL("drop Table if exists activities");
        MyDB.execSQL("drop Table if exists meetings");
        MyDB.execSQL("drop Table if exists en_projects");
        MyDB.execSQL("drop Table if exists per_report");
    }

    public Boolean insertData(String username, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = MyDB.insert("users", null, contentValues);
        if (result == -1) return false;
        else
            return true;
    }

    public Boolean insertData1(String projtitle, String comment) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Projtitle", projtitle);
        contentValues.put("Comment", comment);
        Long result = MyDB.insert("reviews", null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }
    public Boolean insertData2(String projtitle, String grade, String date, String acdy, String time, String dp) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", projtitle);
        contentValues.put("grade", grade);
        contentValues.put("date", date);
        contentValues.put("acdy", acdy);
        contentValues.put("time", time);
        contentValues.put("dp", dp);
        Long result = MyDB.insert("activities", null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }
    public Boolean insertData3(String title, String date, String time, String discussion, String task_to_do, String status, String action) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", title);
        contentValues.put("date", date);
        contentValues.put("time", time);
        contentValues.put("dis", discussion);
        contentValues.put("ttd", task_to_do);
        contentValues.put("status", status);
        contentValues.put("ac", action);
        Long result = MyDB.insert("meetings", null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }
    public Boolean insertData4(String eid, String ept, String s1, String s2, String s3, String s4, String eacdy, String ebatch, String esup) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("projectid", eid);
        contentValues.put("projecttitle", ept);
        contentValues.put("student1", s1);
        contentValues.put("student2", s2);
        contentValues.put("student3", s3);
        contentValues.put("student4", s4);
        contentValues.put("enrollprojectacdy", eacdy);
        contentValues.put("enrollbatch", ebatch);
        contentValues.put("enrollsupervisor", esup);

        Long result = MyDB.insert("en_projects", null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }
    public Boolean insertData5(String pt, String s1, String s2, String s3, String s4, String re, String ce, String pe, String pf, String pr, String me, String fe, String ps) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("projecttitle", pt);
        contentValues.put("student1", s1);
        contentValues.put("student2", s2);
        contentValues.put("student3", s3);
        contentValues.put("student4", s4);
        contentValues.put("remark", re);
        contentValues.put("codeevaluation", ce);
        contentValues.put("projectevaluation", pe);
        contentValues.put("performance", pf);
        contentValues.put("participation", pr);
        contentValues.put("midevaluation", me);
        contentValues.put("finalevaluation", fe);
        contentValues.put("projectstatus", ps);

        Long result = MyDB.insert("per_report", null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }


    public Cursor getreviewdata() {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from " + DBTABLE1, null);
        return cursor;
    }
    public Cursor getactivitydata() {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from " + DBTABLE2, null);
        return cursor;
    }
    public Cursor getmeetingdata() {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from " + DBTABLE3, null);
        return cursor;
    }
    public Cursor getenrollprojectdata() {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from " + DBTABLE4, null);
        return cursor;
    }
    public Cursor getreportdata() {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from " + DBTABLE5, null);
        return cursor;
    }


    public Boolean checkusername(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkusernamepassword(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }

}