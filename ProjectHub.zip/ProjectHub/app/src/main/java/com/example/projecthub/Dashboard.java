package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.projecthub.databinding.ActivityDashboardBinding;

import java.util.ArrayList;

public class Dashboard extends DrawerBasedActivity {
    ActivityDashboardBinding activityDashboardBinding;
    Button addproject;
    RecyclerView recycler_enrollproject;
    ArrayList<String> projectid,projecttitle,student1,student2,student3,student4,enrollprojectacdy,enrollbatch,enrollsupervisor;
    DBHelper DB;
    MyAdapterEP adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityDashboardBinding = ActivityDashboardBinding.inflate(getLayoutInflater());
        setContentView(activityDashboardBinding.getRoot());
        allocateActivityTitle("Dashboard");

        addproject =(Button) findViewById(R.id.addproject);
        addproject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNewActivity();
            }
        });

        DB = new DBHelper(this);
        projectid = new ArrayList<>();
        projecttitle = new ArrayList<>();
        student1 = new ArrayList<>();
        student2 = new ArrayList<>();
        student3 = new ArrayList<>();
        student4 = new ArrayList<>();
        enrollprojectacdy = new ArrayList<>();
        enrollbatch = new ArrayList<>();
        enrollsupervisor = new ArrayList<>();
        recycler_enrollproject = findViewById(R.id.recycler_enrollproject);
        adapter =  new MyAdapterEP(this,projectid,projecttitle,student1,student2,student3,student4,enrollprojectacdy,enrollbatch,enrollsupervisor);
        recycler_enrollproject.setAdapter(adapter);
        recycler_enrollproject.setLayoutManager(new LinearLayoutManager(this));
        displayenrollprojectdata();
    }
    private void displayenrollprojectdata() {

        Cursor cursor = DB.getenrollprojectdata();
        if(cursor.getCount()==0){
            Toast.makeText(this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            while(cursor.moveToNext()){
                projectid.add(cursor.getString(0));
                projecttitle.add(cursor.getString(1));
                student1.add(cursor.getString(2));
                student2.add(cursor.getString(3));
                student3.add(cursor.getString(4));
                student4.add(cursor.getString(5));
                enrollprojectacdy.add(cursor.getString(6));
                enrollbatch.add(cursor.getString(7));
                enrollsupervisor.add(cursor.getString(8));
            }
        }

    }

    private void openNewActivity() {
        Intent intent = new Intent(this, Enroll_project.class);
        startActivity(intent);


    }

}