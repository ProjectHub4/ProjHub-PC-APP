package com.example.projecthub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Enroll_project extends AppCompatActivity{

    Button insertenrollproject,showenrollproject;
    EditText pid,pt1,s1,s2,s3,s4,acdy1,batch1,sup1;
    DBHelper MyDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enroll_project);

        pid = (EditText) findViewById(R.id.pid);
        pt1 = (EditText) findViewById(R.id.pt1);
        s1 = (EditText) findViewById(R.id.s1);
        s2 = (EditText) findViewById(R.id.s2);
        s3 = (EditText) findViewById(R.id.s3);
        s4 = (EditText) findViewById(R.id.s4);
        acdy1 = (EditText) findViewById(R.id.acdy1);
        batch1 = (EditText) findViewById(R.id.batch1);
        sup1 = (EditText) findViewById(R.id.sup1);
        insertenrollproject = findViewById(R.id.insertenrollproject);
        showenrollproject = findViewById(R.id.showenrollproject);
        MyDB = new DBHelper(this);

        showenrollproject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Enroll_project.this, Dashboard.class));
            }
        });
        insertproject();
    }
    public void insertproject(){
        insertenrollproject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean Inserted = MyDB.insertData4(pid.getText().toString(),pt1.getText().toString(),s1.getText().toString(),s2.getText().toString(),s3.getText().toString(),s4.getText().toString(),acdy1.getText().toString(),batch1.getText().toString(),sup1.getText().toString());
                if(Inserted){
                    Toast.makeText(Enroll_project.this, "Project inserted", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Enroll_project.this, "Not inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    }
